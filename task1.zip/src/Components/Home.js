import React from 'react'  
import { Button } from '@mui/material';
import { margin } from '@mui/system';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'  
import { MdCancelPresentation  } from "react-icons/md";

import { FaCheck, FaHome } from "react-icons/fa";

class Home extends React.Component {  
  render() {  

    const mystyle = {
      color: "white",
      backgroundColor: "DodgerBlue",
   
      fontFamily: "Arial",
      fontSize: '15px',
      margin:"20px"
      , padding: "20px 100px"
      ,borderRadius: '13px'
      
    };


    return <div style={{display: 'flex', justifyContent: 'center' ,padding:"100px"}}>
      <div>
        <p style={{ fontSize:"20px"}}><b>Select the Qustion to Continue </b></p>
    
    
       
    

      <Link to="/Question1">
      <Button variant="contained" style={mystyle}  > Question 1</Button>
 </Link>
    <br/>
   
      <Link to="/Question2">
      <Button variant="contained" style={mystyle}  >Question 2</Button>
  
  </Link>

    <br/>
   
      <Link to="/Question3">
      <Button variant="contained" style={mystyle} >Question 3</Button>
  
  </Link>

    <br/>



      <Link to="/Question4">
  
      <Button variant="contained" style={mystyle} >Question 4</Button>
  </Link>
      </div>

 
      
      </div>  
  }  
}  
export default Home 