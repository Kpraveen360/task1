// import logo from './logo.svg';
// import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Home from './Components/Home';
// import Demo from './Components/Demo';
// import Contact from './Components/Contact';
// import About from './Components/About';
import NotFound from './Components/NotFound';
import Question1 from './Question1';
import Question2 from './Question2';
import Question3 from './Question3';
import Question4 from './Question4';



function App() {
  return (


    <Router>
      
         {/* <nav>
           
        <ul>
       
          <li><a href="/">Home</a></li>
          <li><a href="/Contact">Contact</a></li>
          <li><a href="/About">About</a></li>
        </ul>
      </nav> */}
   
      <Routes>
        <Route exact path="/" element={<Home/>}/>
        <Route exact path="/Question1" element={<Question1/>}/>
        <Route exact path="/Question2" element={<Question2 />}/>
        <Route exact path="/Question3" element={<Question3 />}/>
        <Route exact path="/Question4" element={<Question4 />}/>
        <Route path="*" element={<NotFound/>}/>
      </Routes>
  
  </Router>
  );
}

export default App;
