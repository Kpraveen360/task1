import React, { Component } from 'react'
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import { Button } from '@mui/material';
import { padding } from '@mui/system';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom' 


export default class Question4 extends Component {
    render() {
        return (
            <div> <div >

      <div style={{display: 'flex', justifyContent: 'center' ,padding:"10px" ,paddingTop:"100px"}}>
<FormControl component="fieldset">
      <FormLabel component="legend">4.Which sport is the Jules Rimet trophy associated?

	
	
	</FormLabel>
      <RadioGroup
        aria-label="Basketball"
        aria-label="Football"
        aria-label="Hockey"
        defaultValue=""
        
        name="radio-buttons-group"
      >
        <FormControlLabel value="Basketball" control={<Radio />} label="Basketball" />
        <FormControlLabel value="Football" control={<Radio />} label="Football" />
        <FormControlLabel value="Hockey" control={<Radio />} label="Hockey" />
      </RadioGroup>
   
    </FormControl>

    </div>
    <br/>
    <div style={{display: 'flex', justifyContent: 'center', marginLeft:"200px" }}>

    <Link to="/">
    <Button variant="contained" style={{padding:"10px 40px" }} > Submit</Button>
 </Link>
   
    </div>
             </div>
            </div>
        )
    }
}
