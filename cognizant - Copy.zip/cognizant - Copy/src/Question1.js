import React, { Component } from 'react'
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import { Button } from '@mui/material';
import { padding } from '@mui/system';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom' 


export default class Question1 extends Component {
    render() {
        return (
            <div> <div >

      <div style={{display: 'flex', justifyContent: 'center' ,padding:"10px" ,paddingTop:"100px"}}>
<FormControl component="fieldset">
      <FormLabel component="legend">1.Where is the permanent secretariat of the SAARC? </FormLabel>
      <RadioGroup
        aria-label="Kathmandu"
        // defaultValue="New Delhi"
        name="radio-buttons-group"
      >
        <FormControlLabel value="Kathmandu" control={<Radio />} label="Kathmandu" />
        <FormControlLabel value="New Delhi" control={<Radio />} label="New Delhi" />
        <FormControlLabel value="Islamabad" control={<Radio />} label="Islamabad" />
      </RadioGroup>
   
    </FormControl>

    </div>
    <br/>
    <div style={{display: 'flex', justifyContent: 'center', marginLeft:"200px" }}>

    <Link to="/">
    <Button variant="contained" style={{padding:"10px 40px" }} > Submit</Button>
 </Link>
   
    </div>
             </div>
            </div>
        )
    }
}
