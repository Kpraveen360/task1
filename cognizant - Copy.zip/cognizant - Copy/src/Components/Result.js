import React from 'react'  
import { Button } from '@mui/material';
import { margin } from '@mui/system';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom'  
import { MdCancelPresentation  } from "react-icons/md";

import { FaCheck } from "react-icons/fa";

class Result extends React.Component {  
  render() {  

    const mystyle = {
      color: "white",
      backgroundColor: "DodgerBlue",
   
      fontFamily: "Arial",
      fontSize: '15px',
      margin:"20px"
      , padding: "20px 100px"
      ,borderRadius: '13px'
      
    };


    return <div style={{display: 'flex', justifyContent: 'center' ,padding:"100px"}}>
      <div>
        <p style={{margin:"20px", fontSize:"40px"}}><b>Results Screen </b></p>
    
    
       
      <Button variant="contained" style={mystyle} > <MdCancelPresentation /> <FaCheck />Question 1</Button>


    <br/>
   
      <Button variant="contained" style={mystyle} >Question 2</Button>
 

    <br/>
   
      <Button variant="contained" style={mystyle} >Question 3</Button>


    <br/>

      <Button variant="contained" style={mystyle} >Question 4</Button>



      </div>

 
      
      </div>  
  }  
}  
export default Result 