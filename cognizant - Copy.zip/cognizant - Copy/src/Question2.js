import React, { Component } from 'react'
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import { Button } from '@mui/material';
import { padding } from '@mui/system';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom' 


export default class Question2 extends Component {
    render() {
        return (
            <div> <div >

      <div style={{display: 'flex', justifyContent: 'center' ,padding:"10px" ,paddingTop:"100px"}}>
<FormControl component="fieldset">
      <FormLabel component="legend">2.Kiran Bedi received Magsaysay Award for government service 	
	</FormLabel>
      <RadioGroup
        aria-label="1992"
        defaultValue="female"
        name="radio-buttons-group"

      >
        <FormControlLabel value="1992" control={<Radio />} label="1992" />
        <FormControlLabel value="1993" control={<Radio />} label="1993" />
        <FormControlLabel value="1994" control={<Radio />} label="1994" />
      </RadioGroup>
   
    </FormControl>

    </div>
    <br/>
    <div style={{display: 'flex', justifyContent: 'center', marginLeft:"200px" }}>

    <Link to="/">
    <Button variant="contained" style={{padding:"10px 40px" }} > Submit</Button>
 </Link>
   
    </div>
             </div>
            </div>
        )
    }
}
